# -*- coding: utf-8 -*-

import scrapy


class ImdbScraperItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
