# -*- coding: utf-8 -*-


class ImdbScraperPipeline(object):
    def process_item(self, item, spider):
        return item
